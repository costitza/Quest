from flask import Flask, Response, request, jsonify, session
from flask_cors import CORS
import depthai as dai
import cv2
import serial
import time

app = Flask(__name__)
CORS(app, supports_credentials=True)
app.secret_key = 'supersecretkey'

# Establish serial connection to Arduino Mega for distance sensors
arduino = serial.Serial('/dev/ttyAMA0', 115200)  # Adjust port and baud rate as needed
time.sleep(2)  # Allow time for serial connection to establish

def read_serial_data():
    if arduino.in_waiting > 0:
        line = arduino.readline().decode('utf-8').rstrip()
        return line
    return None

# Function to create the depthai pipeline (unchanged)
def create_pipeline():
    pipeline = dai.Pipeline()
    cam_rgb = pipeline.createColorCamera()
    xout_rgb = pipeline.createXLinkOut()
    xout_rgb.setStreamName("rgb")
    cam_rgb.setPreviewSize(640, 352)
    cam_rgb.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
    cam_rgb.setInterleaved(False)
    cam_rgb.setColorOrder(dai.ColorCameraProperties.ColorOrder.BGR)
    cam_rgb.preview.link(xout_rgb.input)
    return pipeline

# Initialize the pipeline and device
pipeline = create_pipeline()
device = dai.Device(pipeline)
rgb_queue = device.getOutputQueue(name="rgb", maxSize=30, blocking=False)

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if username == 'quest' and password == 'iosub':
        session['logged_in'] = True
        print("Login successful")
        return jsonify({'success': True}), 200
    else:
        print("Login failed")
        return jsonify({'success': False}), 401

@app.route('/video_feed')
def video_feed():
    if not session.get('logged_in'):
        print("Unauthorized access to video feed")
        return Response(status=401)
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

def generate_frames():
    while True:
        rgb_frame = rgb_queue.tryGet()
        if rgb_frame is not None:
            frame = rgb_frame.getCvFrame()
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/sensor_data')
def sensor_data():
    if not session.get('logged_in'):
        print("Unauthorized access to sensor_data")
        return Response(status=401)
    
    data = read_serial_data()
    if data:
        sensor_data = data.split(',')
        front_distance = int(sensor_data[0])
        right_distance = int(sensor_data[1])
        left_distance = int(sensor_data[2])
        back_distance = int(sensor_data[3])
        temperature = float(sensor_data[4])
        humidity = float(sensor_data[5])
        
        return jsonify({
            'front': front_distance,
            'right': right_distance,
            'left': left_distance,
            'back': back_distance,
            'temperature': temperature,
            'humidity': humidity
        })
    
    return jsonify({
        'error': 'No sensor data received from Arduino'
    }), 500

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=False)

import pyaudio
import threading
import time

# Parameters
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
CHUNK = 1024
DEVICE_INDEX = 3  # Change this to your specific input device index

# Global variables to control the audio stream
audio_stream_active = False
audio_stream_thread = None

def audio_stream():
    global audio_stream_active

    # Initialize PyAudio
    p = pyaudio.PyAudio()

    try:
        # Open input stream
        input_stream = p.open(format=FORMAT,
                              channels=CHANNELS,
                              rate=RATE,
                              input=True,
                              frames_per_buffer=CHUNK,
                              input_device_index=DEVICE_INDEX)

        # Open output stream
        output_stream = p.open(format=FORMAT,
                               channels=CHANNELS,
                               rate=RATE,
                               output=True)

        print("Recording and playing audio.")

        while audio_stream_active:
            try:
                # Read audio data from input stream
                data = input_stream.read(CHUNK)
                # Play audio data to output stream
                output_stream.write(data)
            except IOError as e:
                print(f"IOError: {e}")
                break
    except Exception as e:
        print(f"Error initializing audio stream: {e}")

    # Stop and close streams
    try:
        input_stream.stop_stream()
        input_stream.close()
    except Exception as e:
        print(f"Error closing input stream: {e}")

    try:
        output_stream.stop_stream()
        output_stream.close()
    except Exception as e:
        print(f"Error closing output stream: {e}")

    # Terminate PyAudio
    p.terminate()

def start_audio_stream():
    print("Speak")
    global audio_stream_active, audio_stream_thread

    if not audio_stream_active:
        audio_stream_active = True
        audio_stream_thread = threading.Thread(target=audio_stream)
        audio_stream_thread.start()

def stop_audio_stream():
    global audio_stream_active

    if audio_stream_active:
        audio_stream_active = False
        if audio_stream_thread:
            audio_stream_thread.join()
            print("Audio stream stopped.")

if __name__ == "__main__":
    start_audio_stream()

    # Stop the stream after 2 seconds
    threading.Timer(2, stop_audio_stream).start()

    # Start the stream again after another 2 seconds
    threading.Timer(4, start_audio_stream).start()

    # Stop the stream after another 2 seconds
    threading.Timer(10, stop_audio_stream).start()

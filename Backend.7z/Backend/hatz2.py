from flask import Flask, Response, request, jsonify, session
from flask_cors import CORS
import depthai as dai
import cv2
import serial
import time
import threading
import pyaudio
from pymavlink import mavutil

app = Flask(__name__)
CORS(app, supports_credentials=True)
app.secret_key = 'supersecretkey'

# Establish serial connection to Arduino Mega for distance sensors
arduino = serial.Serial('/dev/ttyUSB0', 115200)  # Adjust port and baud rate as needed
time.sleep(2)  # Allow time for serial connection to establish

audio_stream_thread = None
audio_stream_active = False
audio_stream_stop_event = threading.Event()

# Function to connect to Pixhawk
def connect_pixhawk():
    ports = ['/dev/ttyACM0', '/dev/ttyACM1']
    for port in ports:
        try:
            connection = mavutil.mavlink_connection(port, baud=57600)
            connection.wait_heartbeat()
            print(f"Connected to Pixhawk on {port}")
            return connection
        except Exception as e:
            print(f"Failed to connect to Pixhawk on {port}: {e}")
    raise Exception("Could not connect to Pixhawk on any known port")

# Function to read data from Arduino
def read_serial_data():
    if arduino.in_waiting > 0:
        line = arduino.readline().decode('utf-8').rstrip()
        return line
    return None

# Function to read data from Pixhawk
def read_pixhawk_data():
    while True:
        msg = pixhawk_connection.recv_match(type='RC_CHANNELS', blocking=True)
        if msg:
            task_channel = getattr(msg, 'chan7_raw', None)
            if task_channel is not None:
                arduino.write(f"{task_channel}\n".encode())
                print(f"Sent task channel data to Arduino: {task_channel}")

# Function to create the depthai pipeline
def create_pipeline():
    pipeline = dai.Pipeline()
    cam_rgb = pipeline.createColorCamera()
    xout_rgb = pipeline.createXLinkOut()
    xout_rgb.setStreamName("rgb")
    cam_rgb.setPreviewSize(640, 352)
    cam_rgb.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
    cam_rgb.setInterleaved(False)
    cam_rgb.setColorOrder(dai.ColorCameraProperties.ColorOrder.BGR)
    cam_rgb.preview.link(xout_rgb.input)
    return pipeline

# Initialize the pipeline and device
pipeline = create_pipeline()
device = dai.Device(pipeline)
rgb_queue = device.getOutputQueue(name="rgb", maxSize=30, blocking=False)

# Connect to Pixhawk
pixhawk_connection = connect_pixhawk()
pixhawk_connection.mav.request_data_stream_send(
    pixhawk_connection.target_system,
    pixhawk_connection.target_component,
    mavutil.mavlink.MAV_DATA_STREAM_RC_CHANNELS,
    5,
    1
)

# Function to generate frames for video feed
def generate_frames():
    while True:
        rgb_frame = rgb_queue.tryGet()
        if rgb_frame is not None:
            frame = rgb_frame.getCvFrame()
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    if username == 'quest' and password == 'iosub':
        session['logged_in'] = True
        print("Login successful")
        return jsonify({'success': True}), 200
    else:
        print("Login failed")
        return jsonify({'success': False}), 401

@app.route('/video_feed')
def video_feed():
    if not session.get('logged_in'):
        print("Unauthorized access to video feed")
        return Response(status=401)
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/sensor_data')
def sensor_data():
    if not session.get('logged_in'):
        print("Unauthorized access to sensor_data")
        return Response(status=401)

    data = read_serial_data()
    if data:
        sensor_data = data.split(',')
        front_distance = int(sensor_data[0])
        right_distance = int(sensor_data[1])
        left_distance = int(sensor_data[2])
        back_distance = int(sensor_data[3])
        temperature = float(sensor_data[4])
        humidity = float(sensor_data[5])

        return jsonify({
            'front': front_distance,
            'right': right_distance,
            'left': left_distance,
            'back': back_distance,
            'temperature': temperature,
            'humidity': humidity
        })

    return jsonify({
        'error': 'No sensor data received from Arduino'
    }), 500

# Function to stream audio
def audio_stream():
    global audio_stream_active, audio_stream_stop_event
    p = pyaudio.PyAudio()

    input_stream = p.open(format=pyaudio.paInt16, channels=1, rate=44100, input=True, frames_per_buffer=1024, input_device_index=3)  # Use correct device index
    output_stream = p.open(format=pyaudio.paInt16, channels=1, rate=44100, output=True)

    def generate_audio():
        while audio_stream_active and not audio_stream_stop_event.is_set():
            try:
                # Read audio data from input stream
                data = input_stream.read(1024)
                # Play audio data to output stream
                output_stream.write(data)
                yield data
            except IOError as e:
                print(f"IOError: {e}")
                break

    return Response(generate_audio(), mimetype='audio/wav')

def start_audio_stream():
    global audio_stream_active, audio_stream_thread, audio_stream_stop_event
    if not audio_stream_active:
        audio_stream_active = True
        audio_stream_stop_event.clear()
        audio_stream_thread = threading.Thread(target=audio_stream)
        audio_stream_thread.start()
        print("Audio stream started.")

def stop_audio_stream():
    global audio_stream_active, audio_stream_stop_event
    if audio_stream_active:
        audio_stream_active = False
        audio_stream_stop_event.set()
        if audio_stream_thread:
            audio_stream_thread.join()
        print("Audio stream stopped.")

@app.route('/start_audio', methods=['POST'])
def start_audio():
    if not session.get('logged_in'):
        print("Unauthorized access to start_audio")
        return Response(status=401)

    start_audio_stream()
    return jsonify({'success': True}), 200

@app.route('/stop_audio', methods=['POST'])
def stop_audio():
    if not session.get('logged_in'):
        print("Unauthorized access to stop_audio")
        return Response(status=401)

    stop_audio_stream()
    return jsonify({'success': True}), 200

@app.route('/audio_stream')
def audio_stream_route():
    if not session.get('logged_in'):
        print("Unauthorized access to audio_stream")
        return Response(status=401)
    return audio_stream()

if __name__ == "__main__":
    threading.Thread(target=read_pixhawk_data).start()
    app.run(host='0.0.0.0', port=5000, debug=False)

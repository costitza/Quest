import depthai as dai
import cv2

def create_pipeline():
    pipeline = dai.Pipeline()

    # Define RGB camera
    cam_rgb = pipeline.createColorCamera()
    cam_rgb.setBoardSocket(dai.CameraBoardSocket.CAM_A)
    cam_rgb.setResolution(dai.ColorCameraProperties.SensorResolution.THE_4_K)  # Use 1080p for high-quality video
    cam_rgb.setFps(30)
    cam_rgb.setInterleaved(False)
    cam_rgb.setColorOrder(dai.ColorCameraProperties.ColorOrder.BGR)

    # Create output for RGB camera
    xout_rgb = pipeline.createXLinkOut()
    xout_rgb.setStreamName("rgb")
    cam_rgb.video.link(xout_rgb.input)

    return pipeline

def run_camera():
    pipeline = create_pipeline()

    with dai.Device(pipeline) as device:
        # Output queue will be used to get the RGB frames from the output defined above
        rgb_queue = device.getOutputQueue(name="rgb", maxSize=30, blocking=False)

        while True:
            # Get frame from the RGB queue
            rgb_frame = rgb_queue.tryGet()

            if rgb_frame is not None:
                # Convert the frame to OpenCV format and display it
                frame = rgb_frame.getCvFrame()
                cv2.imshow("RGB Video", frame)

            if cv2.waitKey(1) == ord('q'):
                break

        cv2.destroyAllWindows()

if __name__ == "__main__":
    run_camera()

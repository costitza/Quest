import serial
import time

# Open serial port
ser = serial.Serial('/dev/ttyAMA0', 115200, timeout=1)
ser.flush()

while True:
    ser.write(b'Testing UART\n')  # Send data
    if ser.in_waiting > 0:
        line = ser.readline().decode('utf-8').rstrip()  # Read data
        print(line)
    time.sleep(1)

from flask import Flask, Response, request, jsonify, session
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import depthai as dai
import cv2
import serial
import time
import threading
import pyaudio
from pymavlink import mavutil

app = Flask(__name__)
CORS(app, supports_credentials=True)
socketio = SocketIO(app, cors_allowed_origins="*")
app.secret_key = 'supersecretkey'

# Establish serial connection to Arduino Mega for distance sensors
arduino = serial.Serial('/dev/ttyAMA0', 115200)  # Adjust port and baud rate as needed
time.sleep(2)  # Allow time for serial connection to establish

def connect_pixhawk():
    ports = ['/dev/ttyACM0', '/dev/ttyACM1']
    for port in ports:
        try:
            connection = mavutil.mavlink_connection(port, baud=57600)
            connection.wait_heartbeat()
            print(f"Connected to Pixhawk on {port}")
            return connection
        except Exception as e:
            print(f"Failed to connect to Pixhawk on {port}: {e}")
    raise Exception("Could not connect to Pixhawk on any known port")

def read_serial_data():
    if arduino.in_waiting > 0:
        line = arduino.readline().decode('utf-8').rstrip()
        return line
    return None

def read_pixhawk_data():
    while True:
        msg = pixhawk_connection.recv_match(type='RC_CHANNELS', blocking=True)
        if msg:
            task_channel = getattr(msg, 'chan7_raw', None)
            if task_channel is not None:
                arduino.write(f"{task_channel}\n".encode())
                print(f"Sent task channel data to Arduino: {task_channel}")

def create_pipeline():
    pipeline = dai.Pipeline()
    cam_rgb = pipeline.createColorCamera()
    xout_rgb = pipeline.createXLinkOut()
    xout_rgb.setStreamName("rgb")
    cam_rgb.setPreviewSize(640, 352)
    cam_rgb.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
    cam_rgb.setInterleaved(False)
    cam_rgb.setColorOrder(dai.ColorCameraProperties.ColorOrder.BGR)
    cam_rgb.preview.link(xout_rgb.input)
    return pipeline

pipeline = create_pipeline()
device = dai.Device(pipeline)
rgb_queue = device.getOutputQueue(name="rgb", maxSize=30, blocking=False)

pixhawk_connection = connect_pixhawk()

pixhawk_connection.mav.request_data_stream_send(
    pixhawk_connection.target_system,    
    pixhawk_connection.target_component, 
    mavutil.mavlink.MAV_DATA_STREAM_RC_CHANNELS, 
    5, 
    1  
)

def generate_frames():
    while True:
        rgb_frame = rgb_queue.tryGet()
        if rgb_frame is not None:
            frame = rgb_frame.getCvFrame()
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if username == 'quest' and password == 'iosub':
        session['logged_in'] = True
        print("Login successful")
        return jsonify({'success': True}), 200
    else:
        print("Login failed")
        return jsonify({'success': False}), 401

@app.route('/video_feed')
def video_feed():
    if not session.get('logged_in'):
        print("Unauthorized access to video feed")
        return Response(status=401)
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/sensor_data')
def sensor_data():
    if not session.get('logged_in'):
        print("Unauthorized access to sensor_data")
        return Response(status=401)
    
    data = read_serial_data()
    if data:
        sensor_data = data.split(',')
        front_distance = int(sensor_data[0])
        right_distance = int(sensor_data[1])
        left_distance = int(sensor_data[2])
        back_distance = int(sensor_data[3])
        temperature = float(sensor_data[4])
        humidity = float(sensor_data[5])
        
        return jsonify({
            'front': front_distance,
            'right': right_distance,
            'left': left_distance,
            'back': back_distance,
            'temperature': temperature,
            'humidity': humidity
        })
    
    return jsonify({
        'error': 'No sensor data received from Arduino'
    }), 500

@socketio.on('connect')
def handle_connect():
    print("Client connected")

@socketio.on('disconnect')
def handle_disconnect():
    print("Client disconnected")

def audio_stream():
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=44100, input=True, frames_per_buffer=1024)
    
    while True:
        data = stream.read(1024)
        socketio.emit('audio', data)

@app.route('/start_audio', methods=['POST'])
def start_audio():
    if not session.get('logged_in'):
        print("Unauthorized access to start_audio")
        return Response(status=401)
    
    threading.Thread(target=audio_stream).start()
    return jsonify({'success': True}), 200

if __name__ == "__main__":
    threading.Thread(target=read_pixhawk_data).start()
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
    print("Backend server is running on http://0.0.0.0:5000")
